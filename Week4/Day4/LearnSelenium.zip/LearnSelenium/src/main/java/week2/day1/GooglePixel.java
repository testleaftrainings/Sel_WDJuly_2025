package week2.day1;

public class GooglePixel {

	public int sendMessage() {
		return 6;
	}

	public String takePhoto() {
		return "photoname";
	}

	public static void main(String[] args) {
		GooglePixel pixelOptions = new GooglePixel();
		pixelOptions.sendMessage();
		System.out.println(pixelOptions.sendMessage());
		
		//System.out.println(variableName);

		String takePhoto = pixelOptions.takePhoto();
		System.out.println(takePhoto);

	}
}
