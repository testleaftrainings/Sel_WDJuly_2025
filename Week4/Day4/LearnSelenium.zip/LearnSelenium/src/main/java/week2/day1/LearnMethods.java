package week2.day1;

public class LearnMethods {

	//Main method   - To execute the code
	//Normal method - To perform an action
	//Naming convention - camelCase
	
	//Declare a method
	//AccessModifier returnType methodName(){}
	
	//Class - Mobile
	//Name of the method -makeCall(), takePhoto(), sendMessage()
	public static void main(String[] args) {
		
	}
}
