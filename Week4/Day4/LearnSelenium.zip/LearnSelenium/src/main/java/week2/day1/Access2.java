package week2.day1;

public class Access2 {
	public static void main(String[] args) {
		Access1 objName = new Access1();
		objName.depositAmount();

	}
}
