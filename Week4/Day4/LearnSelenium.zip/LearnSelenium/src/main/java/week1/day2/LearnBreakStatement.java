package week1.day2;

public class LearnBreakStatement {

	public static void main(String[] args) {
		
		for (int i = 1; i < 5; i++) {
			if (i == 3) {
				break;
			}
			System.out.println(i);
		}

	}

}
