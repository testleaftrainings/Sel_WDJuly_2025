package week1.day2;

public class LearnIfCondition {

	public static void main(String[] args) {
		int x=20;
		int y=20;
		//20<20
		if(x<y) {
			System.out.println("x is smaller than y");
		}
		else {
			System.out.println("x is greater than y");
		}

	}

}
