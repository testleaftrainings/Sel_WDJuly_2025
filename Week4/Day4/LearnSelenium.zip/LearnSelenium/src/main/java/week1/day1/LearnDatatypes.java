package week1.day1;

public class LearnDatatypes {

	public static void main(String[] args) {

		// byte
		byte age = 31;

		// short
		short ageOfPerson = 128;

		// int
		int amount = 40000;

		long mobileNumber = 8925411170L;

		// float
		float rateOfInterest = 10.49F;

		float rupee = 1.2345678912345f;
		// System.out.println(rupee);

		double dollar = 1.2345678912345;
		// System.out.println(dollar);

		// char
		char logo = 'T';

		// boolean
		boolean doYouKnowJava = true;

		// String
		String name = "Vineeth";
		System.out.println("My name is " + name);
		System.out.println(name + " " + age);

	}

}
