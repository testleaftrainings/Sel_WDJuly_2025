package week3.day3;

public class LearnFinal1 {

	public static void main(String[] args) {
		int number=7;
		number=number+1;
		System.out.println(number);
		
		//final int num=21;
		//num=num+1;
		

	}

}
