package week3.day2;
//AM   keyword   InterfaceName
public interface LearnInterface {
	
	//abstract method or unimplemented method
	public void methodName();
	

}
