package week3.day3;

//                 Child extends Parent
public class LearnFinal3 extends LearnFinal2 {
	
	public void finalMethod() {
		System.out.println("This is a final method");

	}

}
