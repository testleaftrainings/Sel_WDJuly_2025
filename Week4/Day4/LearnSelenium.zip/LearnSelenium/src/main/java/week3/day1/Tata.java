package week3.day1;

//          Child        Parent
public class Tata extends Car {

	public void sevenSeater() {
		System.out.println("seater");

	}
}
