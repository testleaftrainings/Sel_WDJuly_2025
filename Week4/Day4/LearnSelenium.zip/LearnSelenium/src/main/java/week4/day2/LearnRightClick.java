package week4.day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class LearnRightClick {

	public static void main(String[] args) {
		       // Launch the Browser
				ChromeDriver driver = new ChromeDriver();

				// Load the url - get
				driver.get("https://swisnl.github.io/jQuery-contextMenu/demo.html");

				// Maximize the browser
				driver.manage().window().maximize();
				
				Actions act=new Actions(driver);
				
				WebElement rightClcikEle = driver.findElement(By.xpath("//span[text()='right click me']"));

				act.contextClick(rightClcikEle).perform();
	}

}
