package week4.day2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnWebtables {

	public static void main(String[] args) {

		// Launch the Browser
		ChromeDriver driver = new ChromeDriver();

		// Load the url - get
		driver.get("https://leafground.com/table.xhtml");

		// Maximize the browser
		driver.manage().window().maximize();

		// Locate the Table
		WebElement table = driver.findElement(By.xpath("//span[text()='Customer Analytics Table']/following::table[2]/tbody"));

		// To count the number of rows
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		int rowsCount = rows.size();
		System.out.println(rowsCount);

		// To count the number of columns
		List<WebElement> columns = driver.findElements(By.xpath("//span[text()='Customer Analytics Table']/following::table[2]/tbody/tr[1]/td"));
		int columnCount = columns.size();
		System.out.println(columnCount);

		// To retieve a particular value
		WebElement row1col2Ele = driver.findElement(By.xpath("//span[text()='Customer Analytics Table']/following::table[2]/tbody/tr[1]/td[2]"));

		String row1col2EleText = row1col2Ele.getText();
		System.out.println(row1col2EleText);

		// To retrieve the entire row
		List<WebElement> row1 = driver.findElements(By.xpath("//span[text()='Customer Analytics Table']/following::table[2]/tbody/tr[1]/td"));
		
		for (int i = 0; i < row1.size(); i++) {
			String text = row1.get(i).getText();
			System.out.println(text);
		}
		// To retrieve the entire data
		List<WebElement> allData = driver.findElements(By.xpath("//span[text()='Customer Analytics Table']/following::table[2]/tbody/tr/td"));
		for (int i = 0; i < allData.size(); i++) {
			String text = allData.get(i).getText();
			System.out.println(text);
		}
	}
}
