package week1.day2;

public class FindOddOrEven {

	public static void main(String[] args) {
		int number = 4;

		if (number % 2 == 0) {
			System.out.println("The number is Even");
		}

		else {
			System.out.println("The number is Odd");
		}

	}

}
