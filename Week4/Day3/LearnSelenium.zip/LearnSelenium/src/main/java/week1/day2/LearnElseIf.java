package week1.day2;

public class LearnElseIf {

	public static void main(String[] args) {
		int x = 20;
		int y = 20;

		if (x < y) {
			System.out.println("x is smaller than y");
		} else if (x > y) {
			System.out.println("x is greater than y");
		}

		else {
			System.out.println("x is equal to y");
		}

	}

}
