package week4.day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class LearnScroll {

	public static void main(String[] args) {
		// Launch the Browser
		ChromeDriver driver = new ChromeDriver();

		// Load the url - get
		driver.get("https://www.amazon.in/");

		// Maximize the browser
		driver.manage().window().maximize();

		// Create Object
         Actions act=new Actions(driver);
         
         //Find the element
         WebElement scrollEle = driver.findElement(By.linkText("Conditions of Use & Sale"));
	
	    act.scrollToElement(scrollEle).perform();
	    
	    scrollEle.click();
	
	}

}
