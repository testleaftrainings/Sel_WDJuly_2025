package week2.day1;

public class LearnDefaultValues {
	
	public void method1(int number, String name, boolean status) {
		
	}
	

	public static void main(String[] args) {
		LearnDefaultValues objName=new LearnDefaultValues();
		objName.method1(0, null, false);
	}

}
