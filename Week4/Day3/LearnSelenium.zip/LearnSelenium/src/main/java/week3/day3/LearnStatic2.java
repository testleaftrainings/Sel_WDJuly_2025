package week3.day3;

public class LearnStatic2 {

	public static void main(String[] args) {

		// ClassName.methodName();
		LearnStatic.method2();
	}

}
