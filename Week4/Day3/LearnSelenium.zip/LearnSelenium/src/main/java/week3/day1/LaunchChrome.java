package week3.day1;

public class LaunchChrome {
	
	public void launchBrowser() {
		System.out.println("Chrome launched successfully");

	}
	
	public static void main(String[] args) {
		LaunchChrome browse=new LaunchChrome();
		browse.launchBrowser();
	}

}
