package week3.day2;

public abstract class Axis implements Rbi{
	
	//implemented method
	public void goldLoan() {
		System.out.println("Gold loan");

	}
	
	//unimplemented or abstract method
	public abstract void houseLoan();

}
