package week3.day3;

public final class LearnFinal2 {

	public final void finalMethod() {
		System.out.println("This is a final method");

	}

}
