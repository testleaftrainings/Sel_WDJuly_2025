package week3.day2;

public interface Rbi {
	
	public abstract void mandatoryKYC();
	
	public void depositAmount();

}
