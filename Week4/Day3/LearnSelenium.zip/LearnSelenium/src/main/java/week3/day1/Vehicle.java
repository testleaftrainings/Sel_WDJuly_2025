package week3.day1;

public class Vehicle {

	public void makeHorn() {
		System.out.println("Horn");

	}

	public static void main(String[] args) {
		Vehicle vehicleOptions = new Vehicle();
		vehicleOptions.makeHorn();

	}

}
