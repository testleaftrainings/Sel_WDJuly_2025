package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {

	//public EdgeDriver driver;
	
	private static final ThreadLocal<EdgeDriver> driver=new ThreadLocal<EdgeDriver>();
	
	public static Properties prop;
	
	public void setDriver() {
		driver.set(new EdgeDriver());
	}
	
   public EdgeDriver getDriver() {
		EdgeDriver edgeDriver = driver.get();
		return edgeDriver;
	}
	
	public String filename;


	@BeforeMethod
	public void preConditions() throws IOException {
		//driver = new EdgeDriver();
		//step1:
				FileInputStream fis=new FileInputStream("src/main/resources/french.properties");
				
				//Step2:
				prop=new Properties();
				
				//Step3
				prop.load(fis);
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps");
		getDriver().manage().window().maximize();

	}

	@AfterMethod
	public void postConditions() {
		getDriver().close();

	}
	@DataProvider(name="fetchdata")
	public String[][] setData() throws IOException {
		String[][] readData = ReadExcel.readData(filename);
        return readData;
	}

}
