package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {
	
	
	
	@And("Enter the username as {string}")
	public LoginPage enterUsername(String username) {
		String user = prop.getProperty("username");
		getDriver().findElement(By.id("username")).sendKeys(user);
		return this;

	}
	@And("Enter the password as {string}")
	public LoginPage enterPassword(String password) {
		String pass = prop.getProperty("password");
		getDriver().findElement(By.id("password")).sendKeys(pass);
        return this;
	}
	@When("Click on Login button")
	public WelcomePage clickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
        //WelcomePage wp=new WelcomePage();
        //return wp;
		return new WelcomePage();   
	}
	
	@Then("It should be logged in")
	public void it_should_be_logged_in() {
		System.out.println("Login successful");
	}
	
	@But("It should error message")
	public void it_should_error_message() {
		System.out.println("It throws the error message");
	}

}
