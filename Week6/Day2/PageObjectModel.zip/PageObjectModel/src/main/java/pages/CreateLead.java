package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;

public class CreateLead extends BaseClass {
	
public CreateLead(EdgeDriver driver) {
	this.driver=driver;
	}

public CreateLead enterCompanyName(String companyName) {
	driver.findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
    return this;
	}

public CreateLead enterFirstName(String firstname) {
	
	driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstname);
	return this;
}

public CreateLead enterLastName(String lastname) {
	
	driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastname);
	return this;
}

public ViewLeadPage clickCreateLead() {
	
	driver.findElement(By.name("submitButton")).click();
	return new ViewLeadPage(driver);
}

	
}
