package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateLead extends BaseClass {
	
public CreateLead(EdgeDriver driver) {
	this.driver=driver;
	}
@Given("Enter the companyname as (.*)$")
public CreateLead enterCompanyName(String companyName) {
	driver.findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
    return this;
	}
@And("Enter the firstname as (.*)$")
public CreateLead enterFirstName(String firstname) {
	
	driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstname);
	return this;
}
@And("Enter the lastname as (.*)$")
public CreateLead enterLastName(String lastname) {
	
	driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastname);
	return this;
}
@When("Click on the CreateLead button")
public ViewLeadPage clickCreateLead() {
	
	driver.findElement(By.name("submitButton")).click();
	return new ViewLeadPage(driver);
}

	
}
