package pages;

import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewLeadPage extends BaseClass {
	
   public ViewLeadPage(EdgeDriver driver) {
	   this.driver=driver;
	}
   @Then("Lead should be created")
	public ViewLeadPage verifyLead() {
		System.out.println("CreateLead successful");
        return this;
	}

}
