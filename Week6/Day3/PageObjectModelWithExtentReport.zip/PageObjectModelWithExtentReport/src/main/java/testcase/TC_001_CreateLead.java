package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001_CreateLead extends BaseClass {

	@BeforeTest
	public void setValues() {
		filename="TC_001_CreateLead";
		tescaseName="CreateLead";
		testcaseDescription="CreateLead with multiple data";
		testAuthorName="Hari";
		testCategory="Regression";

	}
	
	@Test(dataProvider = "fetchdata")
	public void createLead(String username, String password, String companyname, String firstname, String lastname) {
		LoginPage lp=new LoginPage();
        lp.enterUsername(username)
        .enterPassword(password)
        .clickLoginButton()
        .clikCrmsfa()
        .clickLeadsLink()
        .clickCreateLeadLink()
        .enterCompanyName(companyname)
        .enterFirstName(firstname)
        .enterLastName(lastname)
        .clickCreateLead()
        .verifyLead();
	}
	
}
