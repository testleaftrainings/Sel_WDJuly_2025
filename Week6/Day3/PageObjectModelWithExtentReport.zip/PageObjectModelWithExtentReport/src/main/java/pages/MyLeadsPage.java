package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;

public class MyLeadsPage extends BaseClass {
	

@And("Click on the CreateLead link")
public CreateLead clickCreateLeadLink() {
	getDriver().findElement(By.linkText("Create Lead")).click();
	return new CreateLead();
}
}
