package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateLead extends BaseClass {
	

@Given("Enter the companyname as (.*)$")
public CreateLead enterCompanyName(String companyName) {
	getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
    return this;
	}
@And("Enter the firstname as (.*)$")
public CreateLead enterFirstName(String firstname) {
	
	getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(firstname);
	return this;
}
@And("Enter the lastname as (.*)$")
public CreateLead enterLastName(String lastname) {
	
	getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lastname);
	return this;
}
@When("Click on the CreateLead button")
public ViewLeadPage clickCreateLead() {
	
	getDriver().findElement(By.name("submitButton")).click();
	return new ViewLeadPage();
}

	
}
