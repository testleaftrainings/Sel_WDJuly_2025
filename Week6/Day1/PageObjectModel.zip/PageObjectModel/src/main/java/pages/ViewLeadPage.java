package pages;

import base.BaseClass;

public class ViewLeadPage extends BaseClass {
	
	public ViewLeadPage verifyLead() {
		System.out.println("CreateLead successful");
        return this;
	}

}
