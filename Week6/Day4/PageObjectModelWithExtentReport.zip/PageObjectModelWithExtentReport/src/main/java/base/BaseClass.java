package base;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {

	//public EdgeDriver driver;
	
	private static final ThreadLocal<EdgeDriver> driver=new ThreadLocal<EdgeDriver>();
	
	
	public void setDriver() {
		driver.set(new EdgeDriver());
	}
	
   public EdgeDriver getDriver() {
		EdgeDriver edgeDriver = driver.get();
		return edgeDriver;
	}
	
	public String filename;
	public String tescaseName,testcaseDescription,testAuthorName,testCategory;
	public static ExtentReports extent;
	public static ExtentTest test;
	
	@BeforeSuite
	public void startReport() {
		        // Step1: set up the path
				ExtentHtmlReporter report=new ExtentHtmlReporter("./Reports/LeaftapsFunctionality.html");

				//Step2: Create a test
				extent=new ExtentReports();
				
				//Step3:Attach the test to the reports
				extent.attachReporter(report);

	}
	@BeforeClass
	public void testcaseDetails() {
		test = extent.createTest(tescaseName, testcaseDescription);
		test.assignAuthor(testAuthorName);
		test.assignCategory(testCategory);
	}
	
	@AfterSuite
	public void stopReport() {
		extent.flush();

	}
	//                            pass           username
	public void reportStep(String status, String message) throws IOException {
		if(status.equalsIgnoreCase("pass")) {                                         //image12345
			test.pass(message, MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/image"+takeSnap()+".png").build());
		}

		else {
			test.fail(message, MediaEntityBuilder.createScreenCaptureFromPath("./Snaps/image"+takeSnap()+".png").build());
		}
	}
	
	public int takeSnap() throws IOException {
		
		
		int randomNumber = (int)(Math.random()*999999+999999);
		System.out.println(randomNumber);
		
		
		//Step1:
		File source = getDriver().getScreenshotAs(OutputType.FILE);
		
		//step2:
		File destination=new File("./Snaps/image"+randomNumber+".png");
		
		//Step3:
		FileUtils.copyFile(source, destination);
		
		return randomNumber;

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	@BeforeMethod
	public void preConditions() {
		//driver = new EdgeDriver();
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps");
		getDriver().manage().window().maximize();

	}

	@AfterMethod
	public void postConditions() {
		getDriver().close();

	}
	@DataProvider(name="fetchdata")
	public String[][] setData() throws IOException {
		String[][] readData = ReadExcel.readData(filename);
        return readData;
	}

}
