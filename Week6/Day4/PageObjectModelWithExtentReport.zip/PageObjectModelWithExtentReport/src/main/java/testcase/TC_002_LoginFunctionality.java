package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002_LoginFunctionality extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		filename="TC_002_LoginFunctionality";
		tescaseName="Login";
		testcaseDescription="Login with Valid credentials";
		testAuthorName="Vineeth";
		testCategory="Smoke";

	}
	
	@Test(dataProvider = "fetchdata")
	public void loginFunctionality(String username, String password) throws IOException {
		LoginPage lp=new LoginPage();
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton();

	}
	

}
